package br.com.fiap.navi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NaviApplicationTests {

    @Test
    void contextLoads() {
    }

}
